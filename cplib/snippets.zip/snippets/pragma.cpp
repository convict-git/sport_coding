#pragma GCC       optimize ("Ofast")
#pragma GCC       optimize ("unroll-loops") /* can make things slower */
#pragma GCC       target   ("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#pragma GCC       optimize ("-ffloat-store")
